"""
Pydantic schemas for API request/response validation
"""
from pydantic import BaseModel, EmailStr, Field, validator
from typing import Optional, List
from datetime import datetime
from enum import Enum
from uuid import UUID


# Enums
class JurisdictionLevel(str, Enum):
    FEDERAL = "federal"
    STATE = "state"
    COUNTY = "county"
    CITY = "city"


class MeasureStatus(str, Enum):
    INTRODUCED = "introduced"
    SCHEDULED = "scheduled"
    IN_COMMITTEE = "in_committee"
    PASSED = "passed"
    FAILED = "failed"
    TABLED = "tabled"
    WITHDRAWN = "withdrawn"
    UNKNOWN = "unknown"


class VoteValue(str, Enum):
    YES = "yes"
    NO = "no"


class OfficialVoteValue(str, Enum):
    YEA = "yea"
    NAY = "nay"
    ABSTAIN = "abstain"
    ABSENT = "absent"
    PRESENT = "present"
    NOT_VOTING = "not_voting"
    UNKNOWN = "unknown"


class ContentType(str, Enum):
    HTML = "html"
    PDF = "pdf"
    API = "api"
    TEXT = "text"


# Address schemas
class Address(BaseModel):
    line1: str = Field(..., min_length=1, max_length=200)
    line2: Optional[str] = Field(None, max_length=200)
    city: str = Field(..., min_length=1, max_length=100)
    state: str = Field(..., min_length=2, max_length=2)
    postal_code: str = Field(..., min_length=5, max_length=10)
    country: str = Field(default="US", min_length=2, max_length=2)


class AddressPublic(BaseModel):
    """Public address info (no line1/line2)"""
    city: str
    state: str
    postal_code: str
    country: str


# Auth schemas
class UserSignup(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=8)
    address: Address


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class TokenRefresh(BaseModel):
    refresh_token: str


class Tokens(BaseModel):
    access_token: str
    refresh_token: str


class UserResponse(BaseModel):
    id: UUID
    email: str


class LocationResolution(BaseModel):
    lat: Optional[float] = None
    lon: Optional[float] = None
    divisions_resolved: bool


class SignupResponse(BaseModel):
    user: UserResponse
    tokens: Tokens
    location: LocationResolution


# Profile schemas
class Location(BaseModel):
    lat: Optional[float] = None
    lon: Optional[float] = None


class Preferences(BaseModel):
    topics: List[str] = Field(default_factory=list)
    notify_enabled: bool = True


class ProfileResponse(BaseModel):
    user: UserResponse
    address: AddressPublic
    location: Location
    preferences: Preferences


# Feed schemas
class Source(BaseModel):
    label: str
    url: str
    ctype: ContentType


class FeedCard(BaseModel):
    measure_id: UUID
    title: str
    level: JurisdictionLevel
    jurisdiction_name: str
    status: MeasureStatus
    scheduled_for: Optional[datetime] = None
    topic_tags: List[str]
    summary_short: Optional[str] = None
    sources: List[Source]
    user_vote: Optional[VoteValue] = None


class FeedResponse(BaseModel):
    items: List[FeedCard]
    next_cursor: Optional[str] = None


# Measure detail schemas
class VoteEvent(BaseModel):
    id: UUID
    body: str
    scheduled_for: Optional[datetime] = None
    held_at: Optional[datetime] = None
    result: MeasureStatus


class StatusEvent(BaseModel):
    status: MeasureStatus
    effective_at: datetime


class MeasureInfo(BaseModel):
    id: UUID
    title: str
    level: JurisdictionLevel
    status: MeasureStatus
    introduced_at: Optional[datetime] = None
    scheduled_for: Optional[datetime] = None
    summary_short: Optional[str] = None
    summary_long: Optional[str] = None


class UserVote(BaseModel):
    vote: VoteValue
    created_at: datetime


class MeasureDetail(BaseModel):
    measure: MeasureInfo
    sources: List[Source]
    timeline: List[StatusEvent]
    vote_events: List[VoteEvent]
    user_vote: Optional[UserVote] = None


# Voting schemas
class SwipeRequest(BaseModel):
    vote: VoteValue


class SwipeResponse(BaseModel):
    saved: bool
    user_vote: UserVote


# My Votes schemas
class MyVoteItem(BaseModel):
    measure_id: UUID
    title: str
    level: JurisdictionLevel
    user_vote: VoteValue
    status: MeasureStatus
    scheduled_for: Optional[datetime] = None
    outcome: Optional[MeasureStatus] = None


class MyVotesResponse(BaseModel):
    items: List[MyVoteItem]
    next_cursor: Optional[str] = None


# Matching schemas
class MatchSummary(BaseModel):
    measure_id: UUID
    title: str
    level: JurisdictionLevel
    user_vote: VoteValue
    outcome: MeasureStatus
    match_score: float
    computed_at: datetime


class MatchesResponse(BaseModel):
    items: List[MatchSummary]
    next_cursor: Optional[str] = None


class OfficialMatch(BaseModel):
    official_id: UUID
    name: str
    office: str
    official_vote: OfficialVoteValue
    matches_user: bool


class MatchBreakdown(BaseModel):
    officials: List[OfficialMatch]


class Match(BaseModel):
    match_score: float
    breakdown: MatchBreakdown


class MatchDetail(BaseModel):
    measure_id: UUID
    title: str
    level: JurisdictionLevel
    user_vote: VoteValue
    vote_event: VoteEvent
    match: Match


# Admin schemas
class ConnectorConfig(BaseModel):
    """Base connector configuration"""
    base_url: Optional[str] = None
    poll_interval_minutes: Optional[int] = 15


class ConnectorCreate(BaseModel):
    name: str
    source: str
    enabled: bool = True
    config: dict


class Connector(BaseModel):
    id: UUID
    name: str
    source: str
    enabled: bool
    config: dict
    updated_at: datetime


class IngestionRunRequest(BaseModel):
    connector_name: str


class IngestionRunResponse(BaseModel):
    run_id: UUID
    status: str


# Error schema
class ErrorDetail(BaseModel):
    code: str
    message: str
    details: dict = Field(default_factory=dict)


class ErrorResponse(BaseModel):
    error: ErrorDetail
