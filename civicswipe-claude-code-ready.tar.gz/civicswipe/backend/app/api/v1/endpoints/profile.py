"""
Profile endpoints
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.database import get_db
from app.core.security import encrypt_address, hash_address
from app.schemas import ProfileResponse, AddressPublic, Location, Preferences, Address, UserResponse
from app.models import User, UserProfile, UserPreferences
from app.services.geocoding import geocoding_service
from app.services.division_resolver import division_resolver

router = APIRouter()


async def get_current_user(db: AsyncSession = Depends(get_db)) -> User:
    """Dependency to get current user - TODO: implement JWT validation"""
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="Authentication not fully implemented yet"
    )


@router.get("", response_model=ProfileResponse)
async def get_profile(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get current user profile"""
    stmt = select(UserProfile).where(UserProfile.user_id == current_user.id)
    result = await db.execute(stmt)
    profile = result.scalar_one_or_none()
    
    stmt = select(UserPreferences).where(UserPreferences.user_id == current_user.id)
    result = await db.execute(stmt)
    preferences = result.scalar_one_or_none()
    
    if not profile:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Profile not found")
    
    return ProfileResponse(
        user=UserResponse(id=current_user.id, email=current_user.email),
        address=AddressPublic(
            city=profile.city,
            state=profile.state,
            postal_code=profile.postal_code,
            country=profile.country
        ),
        location=Location(
            lat=float(profile.lat) if profile.lat else None,
            lon=float(profile.lon) if profile.lon else None
        ),
        preferences=Preferences(
            topics=preferences.topics if preferences else [],
            notify_enabled=preferences.notify_enabled if preferences else True
        )
    )


@router.patch("/address")
async def update_address(
    address: Address,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Update user address and re-resolve divisions"""
    coords = await geocoding_service.geocode_address(
        street=address.line1,
        city=address.city,
        state=address.state,
        zip_code=address.postal_code
    )
    
    stmt = select(UserProfile).where(UserProfile.user_id == current_user.id)
    result = await db.execute(stmt)
    profile = result.scalar_one_or_none()
    
    if not profile:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Profile not found")
    
    profile.address_line1_enc = encrypt_address(address.line1)
    profile.address_line2_enc = encrypt_address(address.line2) if address.line2 else None
    profile.city = address.city
    profile.state = address.state
    profile.postal_code = address.postal_code
    profile.country = address.country
    profile.address_hash = hash_address(
        address.line1, address.city, address.state, address.postal_code, address.country
    )
    
    if coords:
        profile.lat = str(coords[0])
        profile.lon = str(coords[1])
        await division_resolver.resolve_divisions(
            db=db, user_id=str(current_user.id), lat=coords[0], lon=coords[1],
            state=address.state, city=address.city
        )
    
    await db.commit()
    return {"updated": True, "divisions_recomputed": coords is not None}


@router.patch("/preferences")
async def update_preferences(
    preferences: Preferences,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Update user preferences"""
    stmt = select(UserPreferences).where(UserPreferences.user_id == current_user.id)
    result = await db.execute(stmt)
    user_prefs = result.scalar_one_or_none()
    
    if not user_prefs:
        user_prefs = UserPreferences(user_id=current_user.id)
        db.add(user_prefs)
    
    user_prefs.topics = preferences.topics
    user_prefs.notify_enabled = preferences.notify_enabled
    await db.commit()
    
    return {"updated": True}
