"""
Feed endpoints - personalized swipe feed
"""
from fastapi import APIRouter, Depends, Query, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_, and_
from typing import Optional
from uuid import UUID

from app.core.database import get_db
from app.schemas import FeedResponse, FeedCard, MeasureDetail, JurisdictionLevel, MeasureStatus
from app.models import Measure, UserDivision, UserVote, MeasureSource, MeasureStatusEvent, VoteEvent
from app.api.v1.endpoints.profile import get_current_user

router = APIRouter()


@router.get("/feed", response_model=FeedResponse)
async def get_feed(
    cursor: Optional[str] = Query(None),
    limit: int = Query(20, ge=1, le=50),
    level: Optional[JurisdictionLevel] = Query(None),
    status: Optional[MeasureStatus] = Query(MeasureStatus.SCHEDULED),
    topic: Optional[str] = Query(None),
    current_user = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Get personalized swipe feed
    Returns measures relevant to user's divisions, ranked by scheduled date
    """
    # Get user's divisions
    stmt = select(UserDivision.division_id).where(UserDivision.user_id == current_user.id)
    result = await db.execute(stmt)
    user_division_ids = [row[0] for row in result.fetchall()]
    
    # Build query
    stmt = select(Measure).where(
        or_(
            Measure.level == "federal",  # Always include federal
            Measure.division_id.in_(user_division_ids)  # Or in user's divisions
        )
    )
    
    # Apply filters
    if level:
        stmt = stmt.where(Measure.level == level.value)
    if status:
        stmt = stmt.where(Measure.status == status.value)
    if topic:
        stmt = stmt.where(Measure.topic_tags.contains([topic]))
    
    # Order by scheduled date
    stmt = stmt.order_by(Measure.scheduled_for.asc().nullslast(), Measure.updated_at.desc())
    stmt = stmt.limit(limit)
    
    result = await db.execute(stmt)
    measures = result.scalars().all()
    
    # Build feed cards
    items = []
    for measure in measures:
        # Get sources
        sources_stmt = select(MeasureSource).where(MeasureSource.measure_id == measure.id)
        sources_result = await db.execute(sources_stmt)
        sources = sources_result.scalars().all()
        
        # Get user vote if exists
        vote_stmt = select(UserVote).where(
            and_(UserVote.user_id == current_user.id, UserVote.measure_id == measure.id)
        )
        vote_result = await db.execute(vote_stmt)
        user_vote = vote_result.scalar_one_or_none()
        
        items.append(FeedCard(
            measure_id=measure.id,
            title=measure.title,
            level=JurisdictionLevel(measure.level),
            jurisdiction_name=f"Level: {measure.level}",  # TODO: Get actual jurisdiction name
            status=MeasureStatus(measure.status),
            scheduled_for=measure.scheduled_for,
            topic_tags=measure.topic_tags,
            summary_short=measure.summary_short,
            sources=[
                {"label": s.label, "url": s.url, "ctype": s.ctype}
                for s in sources
            ],
            user_vote=user_vote.vote if user_vote else None
        ))
    
    return FeedResponse(items=items, next_cursor=None)  # TODO: Implement cursor pagination


@router.get("/measures/{measure_id}", response_model=MeasureDetail)
async def get_measure_detail(
    measure_id: UUID,
    current_user = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get detailed information about a specific measure"""
    measure = await db.get(Measure, measure_id)
    if not measure:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Measure not found")
    
    # Get sources
    sources_stmt = select(MeasureSource).where(MeasureSource.measure_id == measure_id)
    sources_result = await db.execute(sources_stmt)
    sources = sources_result.scalars().all()
    
    # Get timeline
    timeline_stmt = select(MeasureStatusEvent).where(
        MeasureStatusEvent.measure_id == measure_id
    ).order_by(MeasureStatusEvent.effective_at.asc())
    timeline_result = await db.execute(timeline_stmt)
    timeline = timeline_result.scalars().all()
    
    # Get vote events
    events_stmt = select(VoteEvent).where(VoteEvent.measure_id == measure_id)
    events_result = await db.execute(events_stmt)
    vote_events = events_result.scalars().all()
    
    # Get user vote
    vote_stmt = select(UserVote).where(
        and_(UserVote.user_id == current_user.id, UserVote.measure_id == measure_id)
    )
    vote_result = await db.execute(vote_stmt)
    user_vote = vote_result.scalar_one_or_none()
    
    return MeasureDetail(
        measure={
            "id": measure.id,
            "title": measure.title,
            "level": measure.level,
            "status": measure.status,
            "introduced_at": measure.introduced_at,
            "scheduled_for": measure.scheduled_for,
            "summary_short": measure.summary_short,
            "summary_long": measure.summary_long
        },
        sources=[{"label": s.label, "url": s.url, "ctype": s.ctype, "is_primary": s.is_primary} for s in sources],
        timeline=[{"status": t.status, "effective_at": t.effective_at} for t in timeline],
        vote_events=[
            {
                "id": ve.id,
                "body": ve.body,
                "scheduled_for": ve.scheduled_for,
                "held_at": ve.held_at,
                "result": ve.result
            }
            for ve in vote_events
        ],
        user_vote={"vote": user_vote.vote, "created_at": user_vote.created_at} if user_vote else None
    )
