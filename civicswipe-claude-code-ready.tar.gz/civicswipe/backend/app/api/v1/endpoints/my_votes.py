"""
My Votes endpoints - user's voting history
"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import Optional

from app.core.database import get_db
from app.schemas import MyVotesResponse, MyVoteItem, JurisdictionLevel, MeasureStatus
from app.models import UserVote, Measure
from app.api.v1.endpoints.profile import get_current_user

router = APIRouter()


@router.get("", response_model=MyVotesResponse)
async def get_my_votes(
    cursor: Optional[str] = Query(None),
    limit: int = Query(20, ge=1, le=50),
    level: Optional[JurisdictionLevel] = Query(None),
    outcome: Optional[MeasureStatus] = Query(None),
    topic: Optional[str] = Query(None),
    current_user = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Get user's voting history with optional filters
    Shows all measures the user has swiped on
    """
    # Build query joining user_votes with measures
    stmt = select(UserVote, Measure).join(
        Measure, UserVote.measure_id == Measure.id
    ).where(
        UserVote.user_id == current_user.id
    )
    
    # Apply filters
    if level:
        stmt = stmt.where(Measure.level == level.value)
    if outcome:
        stmt = stmt.where(Measure.status == outcome.value)
    if topic:
        stmt = stmt.where(Measure.topic_tags.contains([topic]))
    
    # Order by vote date (most recent first)
    stmt = stmt.order_by(UserVote.created_at.desc())
    stmt = stmt.limit(limit)
    
    result = await db.execute(stmt)
    rows = result.fetchall()
    
    # Build response items
    items = []
    for user_vote, measure in rows:
        items.append(MyVoteItem(
            measure_id=measure.id,
            title=measure.title,
            level=JurisdictionLevel(measure.level),
            user_vote=user_vote.vote,
            status=MeasureStatus(measure.status),
            scheduled_for=measure.scheduled_for,
            outcome=MeasureStatus(measure.status) if measure.status in ["passed", "failed"] else None
        ))
    
    return MyVotesResponse(
        items=items,
        next_cursor=None  # TODO: Implement cursor pagination
    )
