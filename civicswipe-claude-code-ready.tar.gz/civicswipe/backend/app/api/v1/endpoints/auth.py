"""
Authentication endpoints
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import (
    get_password_hash,
    verify_password,
    create_access_token,
    create_refresh_token,
    verify_token,
    encrypt_address,
    hash_address
)
from app.schemas import (
    UserSignup,
    UserLogin,
    TokenRefresh,
    SignupResponse,
    Tokens,
    UserResponse,
    LocationResolution
)

router = APIRouter()


@router.post("/signup", response_model=SignupResponse, status_code=status.HTTP_201_CREATED)
async def signup(
    user_data: UserSignup,
    db: AsyncSession = Depends(get_db)
):
    """
    Create new user account (requires address)
    
    - Encrypts and stores address
    - Creates address hash for deduplication
    - Initiates background job for geocoding and division resolution
    """
    # TODO: Check if user already exists
    # TODO: Insert user into database
    # TODO: Encrypt and store address
    # TODO: Trigger background job for geocoding
    # TODO: Trigger background job for division/official resolution
    
    # Placeholder response
    user_id = "placeholder-uuid"
    
    # Create tokens
    access_token = create_access_token(data={"sub": user_id})
    refresh_token = create_refresh_token(data={"sub": user_id})
    
    return SignupResponse(
        user=UserResponse(id=user_id, email=user_data.email),
        tokens=Tokens(access_token=access_token, refresh_token=refresh_token),
        location=LocationResolution(
            lat=None,
            lon=None,
            divisions_resolved=False
        )
    )


@router.post("/login", response_model=Tokens)
async def login(
    credentials: UserLogin,
    db: AsyncSession = Depends(get_db)
):
    """
    Login with email and password
    
    Returns JWT access token and refresh token
    """
    # TODO: Verify credentials
    # TODO: Update last_login_at
    
    # Placeholder
    user_id = "placeholder-uuid"
    
    access_token = create_access_token(data={"sub": user_id})
    refresh_token = create_refresh_token(data={"sub": user_id})
    
    return Tokens(
        access_token=access_token,
        refresh_token=refresh_token
    )


@router.post("/refresh", response_model=Tokens)
async def refresh(
    token_data: TokenRefresh,
    db: AsyncSession = Depends(get_db)
):
    """
    Refresh access token using refresh token
    """
    payload = verify_token(token_data.refresh_token, token_type="refresh")
    
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token"
        )
    
    user_id = payload.get("sub")
    
    # Create new tokens
    access_token = create_access_token(data={"sub": user_id})
    refresh_token = create_refresh_token(data={"sub": user_id})
    
    return Tokens(
        access_token=access_token,
        refresh_token=refresh_token
    )


@router.post("/logout")
async def logout():
    """
    Logout user (client should discard tokens)
    """
    return {"message": "Logged out successfully"}
